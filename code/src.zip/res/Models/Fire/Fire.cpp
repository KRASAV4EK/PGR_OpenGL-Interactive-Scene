#include "Fire.h"

bool Fire::pointFlag = false;