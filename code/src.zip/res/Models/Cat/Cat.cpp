#include "Cat.h"

unsigned int Cat::VAO         = 0;
unsigned int Cat::VBOPos      = 0;
unsigned int Cat::VBONorm     = 0;

unsigned int Cat::vertexCount = 0;

bool Cat::isMoving = false;