#include "Icosphere.h"

bool Icosphere::useToSphere = false;
double Icosphere::lastDynamicScale = 0.0f;